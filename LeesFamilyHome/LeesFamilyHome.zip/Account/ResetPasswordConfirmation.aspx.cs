﻿using System.Web.UI;

namespace LeesFamilyHome.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}